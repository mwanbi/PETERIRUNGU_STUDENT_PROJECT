package com.example.studentmanagementapp;

import androidx.annotation.NonNull;

/**
 * This class represents ONE student
 */
public class Student {

    private int id;          // Student ID
    private String name;     // Student name
    private int age;         // Student age
    private String course;   // Student course

    // Constructor used when reading from database
    public Student(int id, String name, int age, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.course = course;
    }

    // Constructor used when adding new student
    public Student(String name, int age, String course) {
        this.name = name;
        this.age = age;
        this.course = course;
    }

    // Getters (used by DAO)
    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getCourse() { return course; }

    @NonNull
    @Override
    public String toString() {
        return name + " (" + age + ") - " + course;
    }
}
