package com.example.studentmanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Main screen of the app
 */
public class MainActivity extends AppCompatActivity {

    private StudentDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dao = new StudentDAO(this);

        Button btnViewRecords = findViewById(R.id.btnViewRecords);
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);

        btnViewRecords.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ViewRecordsActivity.class);
            startActivity(intent);
        });

        fabAdd.setOnClickListener(v -> showAddStudentDialog());
    }

    private void showAddStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Student");

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_student, null);
        builder.setView(view);

        EditText etName = view.findViewById(R.id.etName);
        EditText etAge = view.findViewById(R.id.etAge);
        EditText etCourse = view.findViewById(R.id.etCourse);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String ageStr = etAge.getText().toString().trim();
            String course = etCourse.getText().toString().trim();

            if (!name.isEmpty() && !ageStr.isEmpty() && !course.isEmpty()) {
                int age = Integer.parseInt(ageStr);
                dao.addStudent(new Student(name, age, course));
                Toast.makeText(this, "Student Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
